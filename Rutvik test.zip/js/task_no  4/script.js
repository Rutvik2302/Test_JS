// DOM for the all page at starting

const taskForm = document.getElementById("taskForm");
const taskList = document.getElementById("taskList");
const searchInput = document.getElementById("search");
const filterCategory = document.getElementById("taskCategory");
const dashboardStats = document.getElementById("dashboardStats");


// by using json.parsh get item from local storge

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

// function of save task

function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}
// reander task by the for each loops

function renderTasks() {
    taskList.innerHTML = "";
    tasks.forEach((task, index) => {
        const taskItem = document.createElement("li");
        taskItem.innerHTML = `
            <strong>${task.text}</strong> - ${task.category} | Due: ${task.dueDate} | Priority: ${task.priority}<br>
            <button class="edit" data-index="${index}">Edit</button>
            <button class="delete" data-index="${index}">Delete</button>
        `;
        taskList.appendChild(taskItem);
    });
    attachEventListeners();
}
// Event listner for submit

taskForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = document.getElementById("taskText").value.trim();
    const category = document.getElementById("taskCategory").value;
    const dueDate = document.getElementById("taskDueDate").value;
    const priority = document.getElementById("taskPriority").value;

    if (text === "") {
        alert("Please enter a task.");
        return;
    }

    // push to the array

    tasks.push({ text, category, dueDate, priority, completed: false });
    saveTasks();
    renderTasks();
    taskForm.reset();
});

// delete button 

function attachEventListeners() {
    document.querySelectorAll(".delete").forEach(button => {
        button.addEventListener("click", (e) => {
            const index = e.target.dataset.index;
            tasks.splice(index, 1);
            saveTasks();
            renderTasks();
        });
    });
// edite button

    document.querySelectorAll(".edit").forEach(button => {
        button.addEventListener("click", (e) => {
            const index = e.target.dataset.index;
            const task = tasks[index];
            document.getElementById("taskText").value = task.text;
            document.getElementById("taskCategory").value = task.category;
            document.getElementById("taskDueDate").value = task.dueDate;
            document.getElementById("taskPriority").value = task.priority;

            tasks.splice(index, 1);
            saveTasks();
            renderTasks();
        });
    });
}
// input filde also for search bar

searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    document.querySelectorAll("#taskList li").forEach((item, index) => {
        item.style.display = tasks[index].text.toLowerCase().includes(query) ? "block" : "none";
    });
});
// filter the data by category

filterCategory.addEventListener("change", () => {
    const category = filterCategory.value;
    document.querySelectorAll("#taskList li").forEach((item, index) => {
        item.style.display = category === "all" || tasks[index].category === category ? "block" : "none";
    });
});

renderTasks();
