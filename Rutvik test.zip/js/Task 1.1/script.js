// create a class name of SmartArray

class SmartArray {
    constructor(rutvik) {
        this.rutvik = rutvik
    }
    toArray() {
        return this.rutvik; 
    }
}
// data

const users = new SmartArray([
    { id: 1, name: 'Alice', role: 'admin' },
    { id: 2, name: 'Bob', role: 'user' },
    { id: 3, name: 'Charlie', role: 'user' },
    { id: 4, name: 'rutvik', role: 'admin' },
    { id: 5, name: 'rutvik', role: 'user' }
]);

// filter by id value all have a unique id value 
let a = Math.floor(Math.random()*4+1)

let filteredUsers = users.toArray().filter(user =>  user.id <= a);
console.log(filteredUsers);

// groupe by type like admin and user etc

let groupbyproprty = users.toArray().filter(user =>  user.role === 'admin');

console.log(groupbyproprty)

// find duplicate value in names and also we can use to find by unique name/id/

function duplicate(name , value){
    return users.toArray().filter(item => item[name] == value);
}
 
console.log(duplicate("name" ,"rutvik"))


// Comma-Separated Values  

let csv = users.toArray().map(item => `${item.id},${item.name},${item.role}`).join("/");
console.log(csv);
