const cache = {};

async function fetchPosts() {
    const container = document.getElementById("posts-container");
    container.innerHTML = "<p>Loading...</p>";

    if (cache.posts) {
        console.log("Using cached data");
        displayPosts(cache.posts);
        return;
    }

    try {
        const response = await fetch("https://jsonplaceholder.typicode.com/posts");
        const data = await response.json();
        cache.posts = data;
        displayPosts(data);
    } catch (error) {
        container.innerHTML = "<p>Error loading posts</p>";
    }
}

function displayPosts(posts) {
    const container = document.getElementById("posts-container");
    container.innerHTML = posts.slice(0, 10).map(post => `
        <div class="post">
            <h3>${post.title}</h3>
            <p>${post.body}</p>
        </div>
    `).join("");
}

document.getElementById("fetch-posts").addEventListener("click", fetchPosts);