// function for making a array

function OptimizeSchedule(id, duration, deadline, priority) {
    this.id = id;
    this.duration = duration * 3600;
    this.deadline = deadline * 24 * 3600;
    this.priority = priority;
}

let scheduleArray = [];

function addSchedule(id, duration, deadline, priority) {
    // for loop for check all the data of the array
    for (let i = 0; i < scheduleArray.length; i++) {
        if (scheduleArray[i].id === id) {
            alert("ID is already there");
            return;
        }
    }
    if (priority < 1 || priority > 5) {
        alert("priority is not valid");
        return;
    }

    let newSchedule = new OptimizeSchedule(id, duration, deadline, priority);
    scheduleArray.push(newSchedule);
    optimizeSchedule();
}
// Sort by a sort function

function optimizeSchedule() {
    scheduleArray.sort((a, b) => {
        if (a.priority !== b.priority) {
            return b.priority - a.priority; 
        }
        return a.deadline - b.deadline;
    });1
}
addSchedule(1, 2, 3, 2);
addSchedule(2, 1, 5, 2);
addSchedule(3, 4, 2, 7);
addSchedule(4, 2, 3, 4);
console.log(scheduleArray);
