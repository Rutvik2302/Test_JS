// Arrow function in variable for search data

let alldata = () => {
    const searchdata = [];
    let table = document.querySelector("#table");
    Array.from(table.children[1].children).forEach(_bodyRow => {
        searchdata.push(Array.from(_bodyRow.children).map(cell => {
            return cell.innerHTML;
        }));
    });
    return searchdata;
};
// Make input for search

const createchild = () => {
    let creat = document.createElement('input');
    creat.classList.add('Search_input');
    return creat;
};
// Find a maching input or data

let find = (arr, searchTerm) => {
    if (!searchTerm) return arr;
    return arr.filter(row => {
        return row.find(item => 
            item.toLowerCase().includes(searchTerm.toLowerCase())
        ) !== undefined;
    });
};
// Filter data 

let filteredData = (data) => {
    let tableBody = document.querySelector("#table").children[1];
    tableBody.innerHTML = ''

    data.forEach(_row => {
        let row = document.createElement('tr');
        _row.forEach(item =>{
            let cell = document.createElement('td');
            cell.innerText = item;
            row.appendChild(cell);
        })
        tableBody.appendChild(row)
    });
}
let init = () => {
    const Search = document.getElementById("Search").appendChild(createchild());
    let tabledat = alldata();
    let searchinput = document.querySelector('.Search_input');

    searchinput.addEventListener('keyup', (e) => {
        filteredData(find(alldata(), e.target.value));
        console.log(filteredData); 
    });
};

init();
